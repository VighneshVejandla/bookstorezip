package com.cts.orderservice.dto;

import lombok.Data;

@Data
public class AuthorDto {
	private Long authId;
	private String authName;
//	private List<BookDto> books;
}

