package com.cts.orderservice.dto;

import lombok.Data;

@Data
public class BookDto {
	private Long bookId;
	private String title;
	private Double price;
	private int stockQuantity;
	private AuthorDto author;
	private CategoryDto category;
}
