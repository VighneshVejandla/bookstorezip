package com.cts.exception;

public class IllegalStateException extends RuntimeException{
    public IllegalStateException(String msg){
        super(msg);
    }
}
