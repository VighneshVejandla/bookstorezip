package com.cts.exception;

public class StatusChangeException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public StatusChangeException(String message) {
		super(message);
	}

}
