package com.cts.dto;

import lombok.Data;

@Data
public class InitiatePaymentDTO {
    private String upiId;
}
