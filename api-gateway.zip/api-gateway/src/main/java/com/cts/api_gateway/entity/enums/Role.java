package com.cts.api_gateway.entity.enums;

public enum Role {
    EMPLOYEE,
    MANAGER,
    ADMIN
}
