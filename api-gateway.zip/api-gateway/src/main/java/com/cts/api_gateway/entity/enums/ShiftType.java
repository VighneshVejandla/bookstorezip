package com.cts.api_gateway.entity.enums;

public enum ShiftType {
    MORNING,
    EVENING,
    NIGHT,
    GENERAL
}
