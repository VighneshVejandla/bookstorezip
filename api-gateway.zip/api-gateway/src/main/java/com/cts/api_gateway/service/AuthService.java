package com.cts.api_gateway.service;

public interface AuthService {

    public void createAuth(Long employeeId, String email);
}
